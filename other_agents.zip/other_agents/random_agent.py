"""This code runs validation tests on a random
    agent that selectes any action with equal probability"""

import flappy_bird_gym
import gym
import time
import json
import numpy as np
import matplotlib.pyplot as plt

agent = "Random"

# create environment
env = gym.make('FlappyBird-v0')

num_tests = 100
scores = []
test_num = []
for test in range(num_tests):
    state = env.reset()
    terminal = False
    score = 0
    while not terminal:
        rand = np.random.random()

        if rand > 0.5:
            action = 1
        else: 
            action = 0
        state, reward, terminal, info = env.step(action)

        # env.render()
        # time.sleep(1 / 75)

        score = info['score']
        scores.append(score)
        test_num.append(test)

env.close()

average_score = np.mean(scores)
maximum_score = np.max(scores)
variance = np.var(scores)
print(f"Average score: {average_score}")
print(f"Maximum score: {maximum_score}")
print(f"Variance: {variance}")

with open(f"validate_info{agent}.txt", 'w') as f:
    f.write(f"Average score: {average_score}\n")
    f.write(f"Maximum score: {maximum_score}\n")
    f.write(f"Variance: {variance}\n")

# plot the validation curve
plt.figure(figsize = (10, 6))
plt.plot(test_num, scores, color='blue')
plt.xlabel('Episode')
plt.ylabel('Score')
plt.title(f'{agent} Agent')
plt.legend()

# save learning curve
learning_curve_file = f'validate_{agent}.png'
plt.savefig(learning_curve_file)
plt.show()