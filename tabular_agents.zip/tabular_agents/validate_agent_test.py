"""This code runs validation tests on an agent
    edit the code to choose the name of the agent
    and select the name of the appropriate Q_table"""

import flappy_bird_gym
import gym
import time
import json
import numpy as np
import matplotlib.pyplot as plt

# choose agent name, comment out appropriate line
agent = "Watkins's Q(Lambda)"
#agent = "SARSA(Lambda)"

# give Q_table file name
q_table_name = "Q_table_Q_lambda.json"
#q_table_name = "Q_table_SARSA_lambda.json"

# load Q-table from json file
with open(f'{q_table_name}', 'r') as f:
    q_table = json.load(f)

# create environmet
env = gym.make('FlappyBird-v0')

# play using loaded Q_table
num_tests = 100
scores = []
test_num = []
for test in range(num_tests):
    state = env.reset()
    terminal = False
    score = 0
    while not terminal:
        state = (round(state[0], 1), round(state[1], 1)) 
        if str(state) not in q_table:
            action = 0 # do nothing if the state is not in the q_table
        else:
            q_values = q_table[str(state)]
            action = np.argmax(q_values)
        state, reward, terminal, info = env.step(action)

        # env.render()
        # time.sleep(1 / 75)

        score = info['score']
        scores.append(score)
        test_num.append(test)

env.close()

average_score = np.mean(scores)
maximum_score = np.max(scores)
variance = np.var(scores)
print(f"Average score: {average_score}")
print(f"Maximum score: {maximum_score}")
print(f"Variance: {variance}")

with open(f"validate_info{agent}.txt", 'w') as f:
    f.write(f"Average score: {average_score}\n")
    f.write(f"Maximum score: {maximum_score}\n")
    f.write(f"Variance: {variance}\n")

# plot the validation curve
plt.figure(figsize = (10, 6))
plt.plot(test_num, scores, color='blue')
plt.xlabel('Episode')
plt.ylabel('Score')
plt.title(f'{agent} Agent')
plt.legend()

# save learning curve
learning_curve_file = f'validate_{agent}.png'
plt.savefig(learning_curve_file)
plt.show()