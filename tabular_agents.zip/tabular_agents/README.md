
## Setup - Tabular methods
Requirements:
```
flappy-bird-gym
gym
numpy
pygame
matplotlib
```
flappy-bird-gym installation:
```$ pip install --no-dependencies flappy-bird-gym```

To test an agent's Q_table performance run "validate_agent_test.py" and select the appropriate Q_table from the comments:

```
# give Q_table file name
#q_table_name = "Q_table_Q_lambda.json"
#q_table_name = "Q_table_SARSA_lambda.json"
```
The agents are in the files "Q_lambda_agent.py" and "SARSA_lambda_agent.py"